import qrcode
import json
import io
from PIL import Image

class QRCodeHandler:
    @staticmethod
    def generate_qr_code(product_data):
        """Generate QR code for a product"""
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        
        # Convert product data to JSON string
        data_string = json.dumps(product_data)
        qr.add_data(data_string)
        qr.make(fit=True)

        # Create QR code image
        img = qr.make_image(fill_color="#2563EB", back_color="white")
        
        # Convert to bytes for Streamlit
        img_byte_arr = io.BytesIO()
        img.save(img_byte_arr, format='PNG')
        img_byte_arr = img_byte_arr.getvalue()
        
        return img_byte_arr

    @staticmethod
    def decode_qr_data(qr_data):
        """Decode QR code data"""
        try:
            return json.loads(qr_data)
        except json.JSONDecodeError:
            return None
