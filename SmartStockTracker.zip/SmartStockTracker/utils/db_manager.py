import pandas as pd
from datetime import datetime
import json

class DatabaseManager:
    def __init__(self):
        # Initialize with sample data
        self.inventory_data = {
            'products': pd.DataFrame({
                'id': range(1, 5),
                'name': ['Product A', 'Product B', 'Product C', 'Product D'],
                'sku_id': ['SKU001', 'SKU002', 'SKU003', 'SKU004'],
                'quantity': [100, 150, 75, 200],
                'price': [29.99, 39.99, 19.99, 49.99],
                'min_threshold': [20, 30, 15, 40]
            }),
            'transactions': pd.DataFrame(columns=['date', 'product_id', 'quantity', 'type'])
        }

    def get_products(self):
        return self.inventory_data['products']

    def get_product(self, product_id):
        product = self.inventory_data['products'][self.inventory_data['products']['id'] == product_id]
        if not product.empty:
            return product.iloc[0].to_dict()
        return None

    def get_transactions(self):
        return self.inventory_data['transactions']

    def add_product(self, name, sku_id, quantity, price, min_threshold):
        new_id = len(self.inventory_data['products']) + 1
        new_product = pd.DataFrame({
            'id': [new_id],
            'name': [name],
            'sku_id': [sku_id],
            'quantity': [quantity],
            'price': [price],
            'min_threshold': [min_threshold]
        })
        self.inventory_data['products'] = pd.concat([self.inventory_data['products'], new_product], ignore_index=True)
        return new_id

    def update_product(self, product_id, updates):
        product_idx = self.inventory_data['products'].index[self.inventory_data['products']['id'] == product_id][0]
        for key, value in updates.items():
            if key in self.inventory_data['products'].columns:
                self.inventory_data['products'].at[product_idx, key] = value
        return True

    def delete_product(self, product_id):
        self.inventory_data['products'] = self.inventory_data['products'][
            self.inventory_data['products']['id'] != product_id
        ]
        return True

    def update_quantity(self, product_id, quantity_change, transaction_type):
        product_idx = self.inventory_data['products'].index[self.inventory_data['products']['id'] == product_id][0]
        self.inventory_data['products'].at[product_idx, 'quantity'] += quantity_change

        new_transaction = pd.DataFrame({
            'date': [datetime.now()],
            'product_id': [product_id],
            'quantity': [abs(quantity_change)],
            'type': [transaction_type]
        })
        self.inventory_data['transactions'] = pd.concat([self.inventory_data['transactions'], new_transaction], ignore_index=True)

    def get_low_stock_alerts(self):
        low_stock = self.inventory_data['products'][
            self.inventory_data['products']['quantity'] <= self.inventory_data['products']['min_threshold']
        ]
        return low_stock