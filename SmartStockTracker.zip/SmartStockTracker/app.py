from flask import Flask, render_template, request, jsonify
from utils.db_manager import DatabaseManager
from utils.qr_handler import QRCodeHandler
import base64

app = Flask(__name__)
db = DatabaseManager()

@app.route('/')
def index():
    products = db.get_products()
    total_products = len(products)
    total_stock = products['quantity'].sum()
    total_value = (products['quantity'] * products['price']).sum()
    low_stock = len(db.get_low_stock_alerts())

    return render_template('index.html',
                         total_products=total_products,
                         total_stock=total_stock,
                         total_value=total_value,
                         low_stock=low_stock,
                         products=products.to_dict('records'))

@app.route('/inventory')
def inventory():
    products = db.get_products()
    return render_template('inventory.html', products=products.to_dict('records'))

@app.route('/add_product', methods=['POST'])
def add_product():
    try:
        name = request.form['name']
        sku_id = request.form['sku_id']
        quantity = int(request.form['quantity'])
        price = float(request.form['price'])
        min_threshold = int(request.form['min_threshold'])

        product_id = db.add_product(name, sku_id, quantity, price, min_threshold)
        return jsonify({'success': True, 'message': 'Product added successfully', 'product_id': product_id})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/api/product/<int:product_id>')
def get_product(product_id):
    product = db.get_product(product_id)
    if product:
        return jsonify(product)
    return jsonify({'error': 'Product not found'}), 404

@app.route('/api/update-product/<int:product_id>', methods=['POST'])
def update_product(product_id):
    try:
        updates = request.json
        if db.update_product(product_id, updates):
            return jsonify({'success': True, 'message': 'Product updated successfully'})
        return jsonify({'success': False, 'message': 'Product not found'}), 404
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/api/delete-product/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    try:
        if db.delete_product(product_id):
            return jsonify({'success': True, 'message': 'Product deleted successfully'})
        return jsonify({'success': False, 'message': 'Product not found'}), 404
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/qr-codes')
def qr_codes():
    products = db.get_products()
    return render_template('qr_codes.html', products=products.to_dict('records'))

@app.route('/analytics')
def analytics():
    products = db.get_products()
    transactions = db.get_transactions()
    return render_template('analytics.html',
                         products=products.to_dict('records'),
                         transactions=transactions.to_dict('records'))

@app.route('/api/generate-qr', methods=['POST'])
def generate_qr():
    product_id = request.json.get('product_id')
    product = db.get_product(product_id)
    if product:
        product_data = {
            'id': int(product['id']),
            'name': product['name'],
            'sku_id': product['sku_id']
        }
        qr_code = QRCodeHandler.generate_qr_code(product_data)
        return jsonify({'qr_code': base64.b64encode(qr_code).decode()})
    return jsonify({'error': 'Product not found'}), 404

@app.route('/api/update-inventory', methods=['POST'])
def update_inventory():
    try:
        product_id = request.json.get('product_id')
        quantity = request.json.get('quantity')
        transaction_type = request.json.get('type', 'Outbound')

        if not all([product_id, quantity]):
            return jsonify({'success': False, 'message': 'Missing required parameters'}), 400

        quantity_change = quantity if transaction_type == 'Inbound' else -quantity
        db.update_quantity(product_id, quantity_change, transaction_type)
        return jsonify({'success': True, 'message': 'Inventory updated successfully'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)