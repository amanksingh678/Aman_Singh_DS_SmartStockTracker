import streamlit as st
from utils.qr_handler import QRCodeHandler
import json

def main():
    st.title("🔲 QR Code Management")

    tab1, tab2 = st.tabs(["Generate QR Codes", "Scan QR Codes"])

    with tab1:
        st.subheader("Generate QR Code")
        products_df = st.session_state.db.get_products()
        
        product_id = st.selectbox(
            "Select Product",
            options=products_df['id'].tolist(),
            format_func=lambda x: products_df[products_df['id'] == x]['name'].iloc[0]
        )

        if st.button("Generate QR Code"):
            product = products_df[products_df['id'] == product_id].iloc[0]
            product_data = {
                'id': int(product['id']),
                'name': product['name'],
                'price': float(product['price'])
            }
            
            qr_code = QRCodeHandler.generate_qr_code(product_data)
            st.image(qr_code, caption=f"QR Code for {product['name']}")

    with tab2:
        st.subheader("Scan QR Code")
        st.write("Upload a QR code image to scan:")
        
        uploaded_file = st.file_uploader("Choose a file", type=['png', 'jpg', 'jpeg'])
        if uploaded_file is not None:
            # In a real implementation, this would use OpenCV to scan the QR code
            st.info("QR code scanning functionality would be implemented here using OpenCV")
            st.write("This would update inventory automatically based on the scanned QR code")

if __name__ == "__main__":
    main()
