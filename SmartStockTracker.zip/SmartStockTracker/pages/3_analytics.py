import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import pandas as pd

def main():
    st.title("📈 Analytics")

    # Get data
    products_df = st.session_state.db.get_products()
    transactions_df = st.session_state.db.get_transactions()

    # Time period selector
    time_period = st.selectbox(
        "Select Time Period",
        ["Last 7 Days", "Last 30 Days", "Last 3 Months"]
    )

    # Calculate date range
    end_date = datetime.now()
    if time_period == "Last 7 Days":
        start_date = end_date - timedelta(days=7)
    elif time_period == "Last 30 Days":
        start_date = end_date - timedelta(days=30)
    else:
        start_date = end_date - timedelta(days=90)

    # Filter transactions
    filtered_transactions = transactions_df[
        (transactions_df['date'] >= start_date) &
        (transactions_df['date'] <= end_date)
    ]

    # Create visualizations
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Transaction History")
        daily_transactions = filtered_transactions.groupby(
            filtered_transactions['date'].dt.date
        )['quantity'].sum().reset_index()
        
        fig = px.line(daily_transactions, x='date', y='quantity',
                      title='Daily Transaction Volume')
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        st.subheader("Transaction Types")
        transaction_types = filtered_transactions['type'].value_counts()
        fig = px.pie(values=transaction_types.values,
                     names=transaction_types.index,
                     title='Transaction Types Distribution')
        st.plotly_chart(fig, use_container_width=True)

    # Product performance
    st.subheader("Product Performance")
    product_performance = filtered_transactions.groupby('product_id')['quantity'].sum()
    product_performance = product_performance.reset_index()
    product_performance = product_performance.merge(
        products_df[['id', 'name']],
        left_on='product_id',
        right_on='id'
    )

    fig = px.bar(product_performance,
                 x='name',
                 y='quantity',
                 title='Product Movement')
    st.plotly_chart(fig, use_container_width=True)

    # Inventory turnover
    st.subheader("Inventory Turnover Analysis")
    turnover_rates = []
    for _, product in products_df.iterrows():
        product_transactions = filtered_transactions[
            filtered_transactions['product_id'] == product['id']
        ]
        turnover = product_transactions['quantity'].sum() / product['quantity']
        turnover_rates.append({
            'name': product['name'],
            'turnover': turnover
        })

    turnover_df = pd.DataFrame(turnover_rates)
    fig = px.bar(turnover_df,
                 x='name',
                 y='turnover',
                 title='Inventory Turnover Rate')
    st.plotly_chart(fig, use_container_width=True)

if __name__ == "__main__":
    main()
