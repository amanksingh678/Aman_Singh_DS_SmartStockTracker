import streamlit as st
from utils.db_manager import DatabaseManager

def main():
    st.title("📦 Inventory Management")

    # Add new product form
    st.subheader("Add New Product")
    with st.form("add_product_form"):
        name = st.text_input("Product Name")
        quantity = st.number_input("Quantity", min_value=0)
        price = st.number_input("Price ($)", min_value=0.0, format="%.2f")
        min_threshold = st.number_input("Minimum Stock Threshold", min_value=0)
        
        submitted = st.form_submit_button("Add Product")
        if submitted and name:
            st.session_state.db.add_product(name, quantity, price, min_threshold)
            st.success(f"Added product: {name}")

    # Display current inventory
    st.subheader("Current Inventory")
    products_df = st.session_state.db.get_products()
    st.dataframe(products_df, use_container_width=True)

    # Update inventory form
    st.subheader("Update Inventory")
    with st.form("update_inventory_form"):
        product_id = st.selectbox(
            "Select Product",
            options=products_df['id'].tolist(),
            format_func=lambda x: products_df[products_df['id'] == x]['name'].iloc[0]
        )
        
        transaction_type = st.radio(
            "Transaction Type",
            options=["Inbound", "Outbound"]
        )
        
        quantity = st.number_input(
            "Quantity",
            min_value=1
        )
        
        submitted = st.form_submit_button("Update Inventory")
        if submitted:
            quantity_change = quantity if transaction_type == "Inbound" else -quantity
            st.session_state.db.update_quantity(product_id, quantity_change, transaction_type)
            st.success("Inventory updated successfully")

if __name__ == "__main__":
    main()
